import requests
import bs4
import re


class Fullmatchtv:

    def __init__(self):
        self.URLS = {"general": "https://fullmatchtv.com",
                     "nba": "https://fullmatchtv.com/nba/",
                     "nfl": "https://fullmatchtv.com/nfl/",
                     "nhl": "https://fullmatchtv.com/nhl/",
                     "mlb": "https://fullmatchtv.com/mlb/",
                     "moto": "https://fullmatchtv.com/other-sports/motorsports/",
                     "afl": "https://fullmatchtv.com/other-sports/afl/",
                     "rugby": "https://fullmatchtv.com/other-sports/rugby/",
                     "mma": "https://fullmatchtv.com/other-sports/wwe-mma/"}

    def __get_event_video_link_s1(self, url):
        link = None
        iter = 0
    
        while link==None:
            iter = iter + 1
            raw_event = requests.get(url)
            parser_event = bs4.BeautifulSoup(raw_event.text, 'html.parser')
            link = parser_event.find('a', attrs={"rel": 'noopener noreferrer'})
            if iter==3 and link==None:
                link = '<a href=http:\\>'

        link = link.get('href') + '#download-tab'
        return link

    def __get_event_video_link_s2(self, url):
        raw_event = requests.get(url)
        parser_event = bs4.BeautifulSoup(raw_event.text, 'html.parser')
        links_event = list()

        for headers in parser_event.find_all('a', attrs={"href": '#'}):
            parameters_str = headers.get('onclick')
            parameters_str = re.sub("download_video", "", parameters_str)
            parameters_str = re.sub("\(", "", parameters_str)
            parameters_str = re.sub("\)", "", parameters_str)
            parameters_str = re.sub("\'", "", parameters_str)
            parameters = re.split("\,", parameters_str)

            links_event.append('https://vidia.tv/dl?op=download_orig&id=' + parameters[0] + '&mode=' + parameters[1] + '&hash=' + parameters[2])

        return links_event

    def __get_event_video_link_s3(self, urls):
        link = None
        links = list()
        iter = 0
    
        for url in urls:
            link = None
            while link==None:
                iter = iter + 1
                raw_event = requests.get(url)
                parser_event = bs4.BeautifulSoup(raw_event.text, 'html.parser')
                link = parser_event.find('a', attrs={"class": 'btn btn-primary mtn-lg'})
                if iter==3 and link==None:
                    link = '<a href=http:\\>'
            links.append(re.sub("https", "http", link.get('href')))

        return links

    def get_list_of_events(self, url):
        raw_page = requests.get(url)
        parser_page = bs4.BeautifulSoup(raw_page.text, 'html.parser')
        links_page = list()

        for headers in parser_page.find_all('h3', attrs={"class": 'entry-title td-module-title'}):
            #if url in headers.contents[0].get('href'):
            links_page.append((headers.contents[0].string, headers.contents[0].get('href')))

        return links_page

    def get_event_video_link(self, url, link_no=0):
        link = self.__get_event_video_link_s1(url)
        links = self.__get_event_video_link_s2(link)
        link = self.__get_event_video_link_s3(links)

        return link


#fullmatchtv = Fullmatchtv()
# = fullmatchtv.get_event_video_link('https://fullmatchtv.com/other-sports/motorsports/formula-1-eifel-grand-prix-11-10-2020/')
#print(link)